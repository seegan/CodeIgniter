<?php
/**
 * The Template for displaying all single posts.
 *
 * @package Twenty Minutes
 */

get_header(); ?>

<section class="breadcrumbs-area" style="background-image: url('<?php echo get_template_directory_uri() ?>/assets/img/banner/breadcrumbs-banner.jpg');">
    <div class="container">
        <div class="breadcrumbs-content">
            <h1>Business</h1>
            <ul>
                <li>
                    <a href="index.html">Home</a> -</li>
                <li>
                    <a href="#">Business</a> -</li>
                <li>Single post style_01</li>
            </ul>
        </div>
    </div>
</section>

<section class="bg-body section-space-less30">
    <div class="container">
        <div class="contentbox">            
            <?php while ( have_posts() ) : the_post(); ?>
                <?php get_template_part( 'content', 'single' ); ?>
                <?php the_post_navigation(); ?>
                <?php
                // If comments are open or we have at least one comment, load up the comment template
				if ( comments_open() || get_comments_number() ) {
					comments_template();
				}
                ?>
            <?php endwhile; // end of the loop. ?>
            <div class="clear"></div>
        </div>        
    <?php get_sidebar();?>
    <div class="clear"></div>
    </div><!-- pagewraps -->
</section><!-- container -->	
<?php get_footer(); ?>