<?php
get_header(); 
?>


<section class="bg-secondary-accent section-space-less4">
    <div class="container">
        <div class="row tab-space2">
            <div class="col-md-8 col-sm-12 mb-4">
                <div class="img-overlay-70 img-scale-animate">
                    <img src="<?php echo get_template_directory_uri() ?>/assets/img/news73.jpg" alt="news" class="img-fluid width-100">
                    <div class="mask-content-lg">
                        <div class="topic-box-sm color-cinnabar mb-20">Politics</div>
                        <div class="post-date-light">
                            <ul>
                                <li>
                                    <span>by</span>
                                    <a href="single-news-1.html">Adams</a>
                                </li>
                                <li>
                                    <span>
                                        <i class="fa fa-calendar" aria-hidden="true"></i>
                                    </span>
                                    March 22, 2017
                                </li>
                            </ul>
                        </div>
                        <h1 class="title-medium-light d-none d-sm-block">
                            <a href="single-news-1.html">If Obama Had Governed Like This in 2017 He'd Be they areatin Transformational.</a>
                        </h1>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="img-overlay-70 img-scale-animate mb-4">
                    <div class="mask-content-sm">
                        <div class="topic-box-sm color-razzmatazz mb-10">Travel</div>
                        <h3 class="title-medium-light">
                            <a href="single-news-3.html">Travel ficen Image mar shaper dam bridge taking</a>
                        </h3>
                    </div>
                    <img src="<?php echo get_template_directory_uri() ?>/assets/img/news74.jpg" alt="news" class="img-fluid width-100">
                </div>
                <div class="img-overlay-70 img-scale-animate mb-4">
                    <div class="mask-content-sm">
                        <div class="topic-box-sm color-apple mb-10">Business</div>
                        <h3 class="title-medium-light">
                            <a href="single-news-1.html">Magnificent Image shaper dam bridge taking</a>
                        </h3>
                    </div>
                    <img src="<?php echo get_template_directory_uri() ?>/assets/img/news75.jpg" alt="news" class="img-fluid width-100">
                </div>
            </div>
        </div>
    </div>
</section>
<section class="bg-accent section-space-less30">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12">
                <div class="ne-isotope">
                    <div class="topic-border color-azure-radiance mb-30">
                        <div class="topic-box-lg color-azure-radiance">More News</div>
                    </div>
                    <div class="featuredContainer">
                        <div class="row">

                            <?php
                                if ( have_posts() ) {
                                    // Start the Loop.
                                    while ( have_posts() ) : the_post();
                                        get_template_part( 'content' );
                                    endwhile;
                                    // Previous/next post navigation.
                                    the_posts_pagination( array(
                                        'mid_size' => 2,
                                        'prev_text' => __( 'Back', 'twenty-minutes' ),
                                        'next_text' => __( 'Next', 'twenty-minutes' ),
                                        'screen_reader_text' => __( 'Posts navigation', 'twenty-minutes' )
                                    ) );
                                } else {
                                    // If no content, include the "No posts found" template.
                                     get_template_part( 'no-results', 'index' );
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="ne-sidebar sidebar-break-md col-lg-4 col-md-12">
                <div class="sidebar-box">
                    <div class="topic-border color-cod-gray mb-30">
                        <div class="topic-box-lg color-cod-gray">Latest Reviews</div>
                    </div>
                    <div class="d-inline-block">
                        <div class="media mb30-list bg-body">
                            <a class="img-opacity-hover" href="single-news-1.html">
                                <img src="img/news/news57.jpg" alt="news" class="img-fluid">
                            </a>
                            <div class="media-body media-padding15">
                                <div class="post-date-dark">
                                    <ul>
                                        <li>
                                            <span>
                                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                            </span>February 10, 2017</li>
                                    </ul>
                                </div>
                                <h3 class="title-medium-dark mb-none">
                                    <a href="single-news-2.html">Can Be Monit roade year with Program.</a>
                                </h3>
                            </div>
                        </div>
                        <div class="media mb30-list bg-body">
                            <a class="img-opacity-hover" href="single-news-2.html">
                                <img src="img/news/news58.jpg" alt="news" class="img-fluid">
                            </a>
                            <div class="media-body media-padding15">
                                <div class="post-date-dark">
                                    <ul>
                                        <li>
                                            <span>
                                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                            </span>June 06, 2017</li>
                                    </ul>
                                </div>
                                <h3 class="title-medium-dark mb-none">
                                    <a href="single-news-3.html">Can Be Monit roade year with Program.</a>
                                </h3>
                            </div>
                        </div>
                        <div class="media mb30-list bg-body">
                            <a class="img-opacity-hover" href="single-news-3.html">
                                <img src="img/news/news59.jpg" alt="news" class="img-fluid">
                            </a>
                            <div class="media-body media-padding15">
                                <div class="post-date-dark">
                                    <ul>
                                        <li>
                                            <span>
                                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                            </span>August 22, 2017</li>
                                    </ul>
                                </div>
                                <h3 class="title-medium-dark mb-none">
                                    <a href="single-news-1.html">Can Be Monit roade year with Program.</a>
                                </h3>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sidebar-box">
                    <div class="topic-border color-cod-gray mb-30">
                        <div class="topic-box-lg color-cod-gray">Newsletter</div>
                    </div>
                    <div class="newsletter-area bg-primary">
                        <h2 class="title-medium-light size-xl line-height-custom">Subscribe to our mailing list to get the new updates!</h2>
                        <img src="img/banner/newsletter.png" alt="newsletter" class="img-fluid mb-10">
                        <p>Subscribe our newsletter to stay updated</p>
                        <div class="input-group stylish-input-group">
                            <input type="text" placeholder="Enter your mail" class="form-control">
                            <span class="input-group-addon">
                                <button type="submit">
                                    <i class="fa fa-angle-right" aria-hidden="true"></i>
                                </button>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php get_footer(); ?>