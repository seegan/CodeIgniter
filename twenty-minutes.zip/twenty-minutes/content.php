<?php
/**
 * @package Greeny Clicks
 */
?>

<div class="col-md-12 col-sm-6 col-12 mb-30">
    <div class="post_lists">
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <div class="media item-shadow-gray bg-body media-none--sm">

                <header class="position-relative width-36 width43-lg">
                    <a href="<?php the_permalink(); ?>" class="img-opacity-hover img-overlay-70">
                        <?php 
                            if (has_post_thumbnail() ){ 
                                the_post_thumbnail('medium', array('class' => 'img-fluid'));
                            } else {
                                echo '<img src="img/news/news53.jpg" alt="news" class="img-fluid">';
                            }
                        ?>
                    </a>
                    <div class="topic-box-top-xs">
                        <div class="topic-box-sm color-cod-gray mb-20"><?php echo get_post_type( get_the_ID() ) ?></div>
                    </div>
                </header>
                <?php if ( is_search() || !is_single() ) { ?>
                <div class="media-body media-padding30 p-mb-none-child">
                    <div class="post-date-dark">
                        <ul>
                            <li>
                                <span>by</span>
                                <a href="<?php the_author_link(); ?>"><?php the_author(); ?></a>
                            </li>
                            <li>
                                <span>
                                    <i class="fa fa-calendar" aria-hidden="true"></i>
                                </span><?php echo get_the_date(); ?>
                            </li>
                        </ul>
                    </div>
                    <h3 class="title-semibold-dark size-lg mb-15">
                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                    </h3>
                    <?php the_excerpt(); ?>
                    <span class="read-more"><a href="<?php the_permalink(); ?>"><?php _e('Read More &rarr;','greeny-clicks'); ?></a></span>
                </div>
                <?php } else { ?>
                    <div class="media-body media-padding30 p-mb-none-child">
                        <?php the_content( __( 'Continue reading <span class="meta-nav">&rarr;</span>', 'greeny-clicks' ) ); ?>
                       <?php
                            wp_link_pages( array(
                                'before' => '<div class="page-links">' . __( 'Pages:', 'twenty-minutes' ),
                                'after'  => '</div>',
                            ) );
                        ?>
                    </div>
                <?php } ?>  
            </div>
        </article>
    </div>
</div>

