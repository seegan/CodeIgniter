<div class="col-sm-12">
	<div class="fill_blank_example">
		Example :- <i>We cannot ........... such a/an ............. act of violence.</i><br>
		To Be Like : <i>We cannot {A} such a/an {B} act of violence.</i>
	</div>
    <div class="row fill_blank_options">
        
    </div>
</div>

