<div class="col-sm-12">
	<div class="match_folowing_example">
		
	</div>
    <div class="row match_folowing_options">
        


		<div class="repeater">
		    <div data-repeater-list="group-a">
		        <div data-repeater-item class="row">
		        	<div class="col-lg-6">
			            <div class="option_box">
			                <div>
			                    <div class="radio radio-success">
			                        <input type="radio" name="single_choice_option" id="radioa" value="a" class="single_choice_option">
			                        <label for="radioa">
			                            Option : A
			                        </label>
			                    </div>                   
			                </div>
			                <textarea class="option_editor"></textarea>
			            </div>	
		        	</div>
		        	<div class="col-lg-6">
			            <div class="option_box">
			                <div>
			                    <div class="radio radio-success">
			                        <input type="radio" name="single_choice_option" id="radioa" value="a" class="single_choice_option">
			                        <label for="radioa">
			                            Option : A
			                        </label>
			                    </div>                   
			                </div>
			                <textarea class="option_editor"></textarea>
			                <input data-repeater-delete type="button" value="Delete"/>
			            </div>	
		        	</div>
		        </div>
		        <div data-repeater-item class="row">
		        	<div class="col-lg-6">
			            <div class="option_box">
			                <div>
			                    <div class="radio radio-success">
			                        <input type="radio" name="single_choice_option" id="radioa" value="a" class="single_choice_option">
			                        <label for="radioa">
			                            Option : A
			                        </label>
			                    </div>                   
			                </div>
			                <textarea class="option_editor"></textarea>
			            </div>	
		        	</div>
		        	<div class="col-lg-6">
			            <div class="option_box">
			                <div>
			                    <div class="radio radio-success">
			                        <input type="radio" name="single_choice_option" id="radioa" value="a" class="single_choice_option">
			                        <label for="radioa">
			                            Option : A
			                        </label>
			                    </div>                   
			                </div>
			                <textarea class="option_editor"></textarea>
			            </div>	
		        	</div>
		        </div>

		    </div>
		    <input data-repeater-create type="button" value="Add"/>
		</div>



    </div>
</div>

