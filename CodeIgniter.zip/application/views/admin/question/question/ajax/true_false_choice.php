<div class="col-sm-12">
	<div class="true_false_example">
	</div>
    <div class="row true_false_options">
        <div class="radio radio-success form-check-inline">
            <input type="radio" id="inlineRadio1" value="option1" name="radioInline" checked>
            <label for="inlineRadio1"> TRUE </label>
    	</div>&nbsp;&nbsp;
		<div class="radio radio-success form-check-inline">
		    <input type="radio" id="inlineRadio2" value="option2" name="radioInline">
		    <label for="inlineRadio2"> FALSE </label>
		</div>
</div>

