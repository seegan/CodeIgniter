
        <script>
            var resizefunc = [];
        </script>

        <!-- Plugins  -->
        <script src="<?php echo base_url(); ?>theme/assets/js/jquery.min.js"></script>
        <script src="<?php echo base_url(); ?>theme/assets/js/popper.min.js"></script><!-- Popper for Bootstrap -->
        <script src="<?php echo base_url(); ?>theme/assets/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url(); ?>theme/assets/js/detect.js"></script>
        <script src="<?php echo base_url(); ?>theme/assets/js/fastclick.js"></script>
        <script src="<?php echo base_url(); ?>theme/assets/js/jquery.slimscroll.js"></script>
        <script src="<?php echo base_url(); ?>theme/assets/js/jquery.blockUI.js"></script>
        <script src="<?php echo base_url(); ?>theme/assets/js/waves.js"></script>
        <script src="<?php echo base_url(); ?>theme/assets/js/wow.min.js"></script>
        <script src="<?php echo base_url(); ?>theme/assets/js/jquery.nicescroll.js"></script>
        <script src="<?php echo base_url(); ?>theme/assets/js/jquery.scrollTo.min.js"></script>
        <script src="<?php echo base_url(); ?>jsplugins/switchery/switchery.min.js"></script>

        <!-- Parsleyjs -->
        <script type="text/javascript" src="<?php echo base_url(); ?>jsplugins/parsleyjs/dist/parsley.min.js"></script>

        <!-- Custom main Js -->
        <script src="<?php echo base_url(); ?>theme/assets/js/jquery.core.js"></script>
        <script src="<?php echo base_url(); ?>theme/assets/js/jquery.app.js"></script>
	
	</body>
</html>