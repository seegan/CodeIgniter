<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <meta name="description" content="Xtragenius - Online Exam Portal">
        <meta name="author" content="Coderthemes">

        <link rel="shortcut icon" href="<?php echo base_url(); ?>theme/assets/images/favicon_1.ico">

        <title>Xtragenius - Online Exam Portal</title>

        <link href="<?php echo base_url(); ?>jsplugins/switchery/switchery.min.css" rel="stylesheet" />

        <link href="<?php echo base_url(); ?>theme/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo base_url(); ?>theme/assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="<?php echo base_url(); ?>theme/assets/css/style.css" rel="stylesheet" type="text/css">
        <link href="<?php echo base_url(); ?>theme/assets/css/custom.css" rel="stylesheet" type="text/css">
        <script src="<?php echo base_url(); ?>theme/assets/js/modernizr.min.js"></script>

    </head>
    <body>